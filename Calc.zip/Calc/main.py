from flask import Flask, render_template, request, redirect, url_for, flash
from flaskext.mysql import MySQL
from flask import Blueprint
from flask_paginate import Pagination, get_page_parameter
import mysql.connector

app = Flask(__name__, template_folder='templates')


app.secret_key = 'many random bytes'
conp = mysql.connector.connect(user='demo', password='root', host='localhost', database='product_details')

@app.route('/admin', methods=['GET', 'POST'])
def index():
    volume = 0
    weight_compair = 0
    weightunit =  0
    total_weight = 0
    order_value = 0
    order_Price = 0
    Paypal_fee_usd = 0
    China_exprice_ind =  0
    Order_price_inr = 0
    Freight_charges = 0
    Insurance_value = 0
    Landing_value=  0
    Assessable_value = 0
    BCD_Value= 0
    Sw_charges = 0
    GST_value = 0
    Shipping_value = 0
    Fuel_value = 0
    CD_total = 0
    GST_value2=  0
    Total_shipping = 0
    # addition
    Total = 0
    GST_recover = 0
    Total_landing_without_GST = 0
    Direct_landing = 0
    Indirect_basic = 0


    Shipping_extra= 0
    Tax_on = 0 
    Total_shipping2 = 0
    China_purchase = 0
    BCD = 0
    CP_BCD = 0
    CP_BCD_TS = 0 
    CP_BCD_TS_Unit = 0 
    # selling1
    Profit_on_cp = 0
    Income_tax_cp = 0
    Selling_1_price  = 0
    Selling_GST = 0
    unit_price_selling  = 0
    Price_Include_GST = 0

    # selling 2  (CP+ BCD )
    Profit= 0
    income_tax22 = 0
    Selling_2_Price= 0
    Selling_2_GST  =0
    unit_price_selling2 =0
    unit_price_Seliing_GST =0

    # selling 3 (CP + BCD+ TS)
    Profit2 = 0
    Income_tax_2 = 0 
    Selling_3_Price = 0
    Selling_3_GST = 0
    unit_price_selling3 = 0
    unit_price_Seliing_GST_2 = 0

    #finals
    Indirect = 0
    USD_TO_RMB = 0
    INR_Value = 0
    final_unit_price = 0
    final_order_value  = 0



    if request.method == "POST":
        details = request.form
        print(details) 
	#get here form data and perform all operation what you wnat to do
        product = details['product']
        SKU = details['SKU']
        length = float(details['length'])
        width = float(details['width'])
        height = float(details['height'])
        weight = float(details['weight'])
        packing = float(details['packing'])
        order_qty = float(details['order_qty'])
        brand_name = details['brand_name']
        brand_c = details['brand_c']
        brand_sc = details['brand_sc']
        # brand_sc = details['brand_sc']
        unit_price = float(details['unit_price'])
        
        direct_unit_price = float(details['direct_unit_price'])
        Paypal = float(details['Paypal'])
        Rate_of_ex_inr = float(details['Rate_of_ex_inr'])
        #  custom
        Freight = float(details['Freight'])
        Insurance = float(details['Insurance'])
        Landing = float(details['Landing'])
        Basic_duty = float(details['Basic_duty'])
        GST = float(details['GST'])
        Shipping_fee = float(details['Shipping_fee'])
        Fuel_charges = float(details['Fuel_charges'] )
        Extra_shipping_per_kg = float(details['Extra_shipping_per_kg'])
        stock_loctn = details['stock_loctn']
        # Company profit


        stocks = details['stocks']
        IRS_Profit = float(details['IRS_Profit'])
        Income_tax = float(details['Income_tax'])
        GST2 = float(details['GST2'])

        # Selli)ng 1


        # final
        RMB = float(details['RMB'])
        RMB_to_INR = float(details['RMB_to_INR'])        


        
        # print(num1,'--------------',num2 , num3)
        volume = (length*width*height)/5000000
        print(volume)

        weight_compair = max(length*width*height/5000000, weight)
        print(weight_compair)

        weightunit = ((max(length*width*height/5000000, weight))*packing)/100 + max(length*width*height/5000000, weight)
        print(weightunit)

        total_weight = ((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))
        print(total_weight)

        order_value = order_qty*unit_price
        print(order_value)

        order_Price = direct_unit_price*order_qty
        print(order_Price)
         


           # china

        Paypal_fee_usd = (direct_unit_price*order_qty*Paypal)/100
        print(Paypal_fee_usd)
        China_exprice_ind = direct_unit_price*order_qty + (direct_unit_price*order_qty*Paypal)/100
        print(China_exprice_ind)
        Order_price_inr = direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr   
        print(Order_price_inr)
        
        # custom duty
  
        Freight_charges = ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100
        print(Freight_charges)

        Insurance_value = (direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000
        print(Insurance_value)

        Landing_value = (direct_unit_price*order_qty + (direct_unit_price*order_qty*Paypal)/100)*(direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Landing/100
        print(Landing_value)

        Assessable_value = (direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr
        print(Assessable_value)

        BCD_Value= ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100        
        print(BCD_Value)

        Sw_charges = (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000        
        print(Sw_charges)

        GST_value = ((((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 +   (direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*GST/100
        print(GST_value) 

        CD_total =((((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 +   (direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*GST/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100        
        print(CD_total)
           
           #shipping 
        Shipping_value = Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight)))
        print(Shipping_value)

        Fuel_value = (Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Fuel_charges/100
        print(Fuel_value)

        GST_value2 = (Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*18/100 
        print(GST_value2)

        Total_shipping = Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + (Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*18/100       
        print(Total_shipping)
       
        # additional
        Total = Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + (Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*18/100  + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100)*GST/100+ (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000 +  ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100        
        print(Total)

        GST_recover = ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000)*GST/100 + (Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*18/100
        print(GST_recover)
        
        Total_landing_without_GST =  (Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + (Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*18/100  + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100)*GST/100+ (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000 +  ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100) - (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000)*GST/100 + (Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*18/100)     
        print(Total_landing_without_GST)

        Direct_landing = direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr     
        print(Direct_landing)

        Indirect_basic = unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty
        print(Indirect_basic)

        Shipping_extra = Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight)))  
        print(Shipping_extra) 

        Tax_on = (Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100
        print(Tax_on)

        Total_shipping2 = (Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100
        print(Total_shipping2)
        
        China_purchase =  direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty
        print(China_purchase)
           
        BCD = ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000        
        print(BCD)

        CP_BCD = direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000        
        print(CP_BCD)
        
        CP_BCD_TS = (Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 +  direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000 
        print(CP_BCD_TS)

        CP_BCD_TS_Unit =  ((Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 +  direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000)/order_qty     
        print(CP_BCD_TS_Unit)

  
        # selling 1

        Profit_on_cp  =  (direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty)*IRS_Profit/100    
        print(Profit_on_cp)

        Income_tax_cp =   ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty)*IRS_Profit/100)*Income_tax/100 
        print(Income_tax_cp)
 
        Selling_1_price =  (Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 +  direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty)*IRS_Profit/100)*Income_tax/100 + (direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty)*IRS_Profit/100    
        print(Selling_1_price)

        Selling_GST =   ((Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 +  direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty)*IRS_Profit/100)*Income_tax/100 + (direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty)*IRS_Profit/100)*GST2/100 + (Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 +  direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty)*IRS_Profit/100)*Income_tax/100 + (direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty)*IRS_Profit/100       
        print(Selling_GST)

        unit_price_selling = ((Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 +  direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty)*IRS_Profit/100)*Income_tax/100 + (direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty)*IRS_Profit/100)/order_qty          
        print(unit_price_selling)

        Price_Include_GST =  (((Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 +  direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty)*IRS_Profit/100)*Income_tax/100 + (direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty)*IRS_Profit/100)*GST2/100 + (Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 +  direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty)*IRS_Profit/100)*Income_tax/100 + (direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty)*IRS_Profit/100)/order_qty       
        print(Price_Include_GST)

        # selling 2
        Profit =    (direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000)*IRS_Profit/100
        print(Profit)
  
        income_tax22 =  ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000)*IRS_Profit/100)*Income_tax/100      
        print(income_tax22)

        Selling_2_Price =   (direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000)*IRS_Profit/100 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000)*IRS_Profit/100)*Income_tax/100  + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000 + (Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100   
        print(Selling_2_Price)

        Selling_2_GST = ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000)*IRS_Profit/100 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000)*IRS_Profit/100)*Income_tax/100  + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000 + (Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100)*GST2/100 + (direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000)*IRS_Profit/100 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000)*IRS_Profit/100)*Income_tax/100  + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000 + (Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100
        print(Selling_2_GST)

        unit_price_selling2 =  ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000)*IRS_Profit/100 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000)*IRS_Profit/100)*Income_tax/100  + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000 + (Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100)/order_qty    
        print(unit_price_selling2) 

        unit_price_Seliing_GST =  (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000)*IRS_Profit/100 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000)*IRS_Profit/100)*Income_tax/100  + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000 + (Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100)*GST2/100 + (direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000)*IRS_Profit/100 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000)*IRS_Profit/100)*Income_tax/100  + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000 + (Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100)/order_qty    
        print(unit_price_Seliing_GST)

        #selling 3

        Profit2 =   ((Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 +  direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000)*IRS_Profit/100    
        print(Profit2)

        Income_tax_2 =  (((Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 +  direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000)*IRS_Profit/100)*Income_tax/100  
        print(Income_tax_2)
       
        Selling_3_Price = (Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 +  direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000 + ((Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 +  direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000)*IRS_Profit/100 + (((Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 +  direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000)*IRS_Profit/100)*Income_tax/100         
        print(Selling_3_Price)
         
        Selling_3_GST =    ((Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 +  direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000 + ((Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 +  direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000)*IRS_Profit/100 + (((Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 +  direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000)*IRS_Profit/100)*Income_tax/100)*GST2/100 +  (Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 +  direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000 + ((Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 +  direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000)*IRS_Profit/100 + (((Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 +  direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000)*IRS_Profit/100)*Income_tax/100    
        print(Selling_3_GST)

        unit_price_selling3 = ((Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 +  direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000 + ((Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 +  direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000)*IRS_Profit/100 + (((Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 +  direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000)*IRS_Profit/100)*Income_tax/100)/order_qty        
        print(unit_price_selling3)

        unit_price_Seliing_GST_2 =  (((Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 +  direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000 + ((Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 +  direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000)*IRS_Profit/100 + (((Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 +  direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000)*IRS_Profit/100)*Income_tax/100)*GST2/100 +  (Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 +  direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000 + ((Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 +  direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000)*IRS_Profit/100 + (((Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))*Income_tax/100 + Extra_shipping_per_kg*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))) + Fuel_charges*(Shipping_fee*(((max(length*width*height/5000000, weight))*packing/100)*order_qty + order_qty*(max(length*width*height/5000000, weight))))/100 +  direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr +  unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty/100 + (((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Insurance*Freight/10000 + ((direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Freight)/100 + direct_unit_price*order_qty*Rate_of_ex_inr + (direct_unit_price*order_qty*Paypal)/100*Rate_of_ex_inr)*Basic_duty)/1000)*IRS_Profit/100)*Income_tax/100)/order_qty    
        print(unit_price_Seliing_GST_2)


        #finals
        Indirect = unit_price*((unit_price - direct_unit_price)/unit_price)
        print(Indirect)

        USD_TO_RMB = unit_price*((unit_price - direct_unit_price)/unit_price)*6.9
        print(USD_TO_RMB)
 
        INR_Value = RMB_to_INR + 0.5
        print(INR_Value) 

        final_unit_price = unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)
        print(final_unit_price)

        final_order_value = unit_price*((unit_price - direct_unit_price)/unit_price)*6.9*(RMB_to_INR + 0.5)*order_qty
        print(final_order_value)


      

        cur = conp.cursor()
        cur.execute("INSERT INTO general_details(brand_name,brand_c ,brand_sc,  volume,weight_compair,weightunit,total_weight ,order_value ,order_Price ,Paypal_fee_usd ,China_exprice_ind ,Order_price_inr ,Freight_charges ,Insurance_value ,Landing_value,Assessable_value ,BCD_Value,Sw_charges ,GST_value ,Shipping_value ,Fuel_value ,CD_total ,GST_value2, Total_shipping ,Total ,GST_recover ,Total_landing_without_GST ,Direct_landing ,Indirect_basic ,Shipping_extra,Tax_on  ,Total_shipping2 ,China_purchase ,BCD ,CP_BCD ,CP_BCD_TS ,CP_BCD_TS_Unit ,Profit_on_cp ,Income_tax_cp ,Selling_1_price  ,Selling_GST ,unit_price_selling  ,Price_Include_GST ,Profit,income_tax22 ,Selling_2_Price,Selling_2_GST ,unit_price_selling2,unit_price_Seliing_GST,Profit2 ,Income_tax_2 ,Selling_3_Price ,Selling_3_GST ,unit_price_selling3 ,unit_price_Seliing_GST_2 ,Indirect ,USD_TO_RMB ,INR_Value ,final_unit_price ,final_order_value,RMB_to_INR,RMB , GST2  , Income_tax ,IRS_Profit, Extra_shipping_per_kg ,Fuel_charges, Shipping_fee, GST , Basic_duty, Landing ,Insurance, Freight, Rate_of_ex_inr, Paypal, direct_unit_price, unit_price, order_qty, packing,weight , height,width,length, SKU,product,stocks,stock_loctn) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s, %s,%s,%s,%s )", (brand_name, brand_c ,brand_sc , volume,weight_compair,weightunit,total_weight ,order_value ,order_Price ,Paypal_fee_usd ,China_exprice_ind ,Order_price_inr ,Freight_charges ,Insurance_value ,Landing_value,Assessable_value ,BCD_Value,Sw_charges ,GST_value ,Shipping_value ,Fuel_value ,CD_total ,GST_value2, Total_shipping ,Total ,GST_recover ,Total_landing_without_GST ,Direct_landing ,Indirect_basic ,Shipping_extra,Tax_on  ,Total_shipping2 ,China_purchase ,BCD ,CP_BCD ,CP_BCD_TS ,CP_BCD_TS_Unit ,Profit_on_cp ,Income_tax_cp ,Selling_1_price  ,Selling_GST ,unit_price_selling  ,Price_Include_GST ,Profit,income_tax22 ,Selling_2_Price,Selling_2_GST ,unit_price_selling2,unit_price_Seliing_GST,Profit2 ,Income_tax_2 ,Selling_3_Price ,Selling_3_GST ,unit_price_selling3 ,unit_price_Seliing_GST_2 ,Indirect ,USD_TO_RMB ,INR_Value ,final_unit_price ,final_order_value,RMB_to_INR,RMB , GST2  , Income_tax ,IRS_Profit, Extra_shipping_per_kg ,Fuel_charges, Shipping_fee, GST , Basic_duty, Landing ,Insurance, Freight, Rate_of_ex_inr, Paypal, direct_unit_price, unit_price, order_qty, packing,weight , height,width,length, SKU,product ,stocks , stock_loctn))
        conp.commit()
        id = cur.lastrowid
        print(id,)
        cur.close()
        
        
    if request.method == 'GET':
        
        cur = conp.cursor()
        id = cur.lastrowid
       
        print(id,'-----------')
        
    return render_template('admin.html', Profit=Profit,Fuel_value=Fuel_value,Indirect=Indirect,Indirect_basic=Indirect_basic, USD_TO_RMB=USD_TO_RMB,final_order_value=final_order_value,final_unit_price=final_unit_price,INR_Value=INR_Value,Profit2=Profit2,Income_tax_2=Income_tax_2,Selling_3_GST=Selling_3_GST ,Selling_3_Price=Selling_3_Price,unit_price_Seliing_GST_2=unit_price_Seliing_GST_2 ,unit_price_selling3=unit_price_selling3,   income_tax22=income_tax22, Selling_2_Price=Selling_2_Price, Selling_2_GST=Selling_2_GST, unit_price_selling2=unit_price_selling2, unit_price_Seliing_GST=unit_price_Seliing_GST,                  Profit_on_cp=Profit_on_cp,Price_Include_GST=Price_Include_GST,unit_price_selling=unit_price_selling ,Selling_1_price=Selling_1_price,Selling_GST=Selling_GST, Income_tax_cp=Income_tax_cp, Total=Total,Tax_on =Tax_on ,CP_BCD=CP_BCD,CP_BCD_TS=CP_BCD_TS,CP_BCD_TS_Unit=CP_BCD_TS_Unit, BCD=BCD,Total_shipping2=Total_shipping2,China_purchase=China_purchase, Shipping_extra= Shipping_extra, Direct_landing= Direct_landing, Total_landing_without_GST=Total_landing_without_GST, GST_recover=GST_recover, Total_shipping=Total_shipping,volume=volume,GST_value2=GST_value2 ,CD_total=CD_total, weightComp=weight_compair, wperv=weightunit, tweight= total_weight, orderv=order_value, orderP=order_Price, Paypal_fee_usd= Paypal_fee_usd,China_exprice_ind= China_exprice_ind, Order_price_inr= Order_price_inr, Freight_charges= Freight_charges, Insurance_value= Insurance_value, Landing_value=Landing_value,   Assessable_value= Assessable_value ,Shipping_value=Shipping_value, GST_value= GST_value,  Sw_charges =Sw_charges, BCD_Value= BCD_Value)

@app.route('/logout', methods=['GET', 'POST'])
def logout():
    if request.method == "GET":
        # id = request.args.get('id')
        print('ghtttttttttttt')
    return render_template('login.html')

@app.route('/admin')
def home():
     return render_template('admin.html')
@app.route('/')
def welcome():
    return render_template('welcome.html')
# route for handling the login page logic
@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        if request.form['username'] != 'admin' or request.form['password'] != ' ':
            error = 'Invalid Username/Password.'
        else:
            return redirect(url_for('home'))
    return render_template('login.html', error=error)

@app.route('/updater_login/', methods=['GET', 'POST'])
def updater():
    error = None
    if request.method == 'POST':
        if request.form['username'] != 'update' or request.form['password'] != ' ':
            error = 'Invalid Username/Password.'
        else:
            return redirect(url_for('M2'))
    return render_template('updater_login.html', error=error)





@app.route('/Database/', methods=['GET', 'POST'])
def M2():
    print('hi we are here--------')
    if request.method == "GET":
        id = request.args.get('id')
        print(id)
        cur = conp.cursor()
        cur.execute("SELECT id, product, SKU,brand_name, brand_c ,  brand_sc, stocks ,stock_loctn FROM general_details")
        details = cur.fetchall()
        for data in details[0:5]:
            print(data, '-------------------------')
            print(details)
    if request.method == "POST":
        id = request.args.get('id')
        print(id)
        if (request.form['product']=="" and request.form['SKU']=="" and request.form['brand_name']=="" and request.form['brand_c']==""):
            detail = []
            cur = conp.cursor()
            cur.execute("SELECT id,  product, SKU, brand_name,, brand_c,  brand_sc,  stocks,stock_loctn    FROM general_details")
            details = cur.fetchall()
        elif (request.form['SKU'] != ""):
            pass
            SKU = request.form['SKU']
            print('============================',SKU)
            cur = conp.cursor()
            cur.execute("SELECT id, product, SKU,brand_name, brand_c ,  brand_sc,  stocks ,stock_loctn FROM general_details where SKU=%s",(SKU,))
            details = cur.fetchall()
        elif (request.form['product'] != ""):
            pass
            product = request.form['product']
            print('============================',product)
            cur = conp.cursor()
            cur.execute("SELECT id, product, SKU,brand_name, brand_c ,  brand_sc,  stocks ,stock_loctn FROM general_details where product=%s",(product,))
            details = cur.fetchall()
        elif (request.form['brand_name'] !=""):
            pass
            brand_name = request.form['brand_name']
            print('============================',brand_name)
            cur = conp.cursor()
            cur.execute("SELECT id, product, SKU,brand_name, brand_c ,  brand_sc,  stocks ,stock_loctn FROM general_details where brand_name=%s",(brand_name,))
            details = cur.fetchall()
        elif (request.form['brand_c'] !=""):
            pass
            brand_c = request.form['brand_c']
            print('============================',brand_c)
            cur = conp.cursor()
            cur.execute("SELECT id, product, SKU,brand_name, brand_c ,  brand_sc, stocks ,stock_loctn FROM general_details where brand_c=%s",(brand_c,))
            details = cur.fetchall()
        else:
            pass
            SKU = request.form['SKU']
            brand_name = request.form['brand_name']
            brand_c = request.form['brand_c']
            cur = conp.cursor()
            cur.execute("SELECT id, product, SKU,brand_name, brand_c , stocks ,stock_loctn  FROM general_details where SKU=%s, product=%s,  brand_name=%s, brand_c=%s",(SKU, brand_name, product, brand_c,))
            details = cur.fetchall()
            
    return render_template('Database.html', detail = details)




@app.route('/Db/', methods=['GET', 'POST'])
def M3():
    print('hi we are here--------')
    if request.method == "GET":
        id = request.args.get('id')
        print(id)
        detail = []
        cur = conp.cursor()
        cur.execute("SELECT id, product,SKU, brand_name, brand_c ,brand_sc, length,width,height,volume,weight ,weight_compair, packing, order_qty, total_weight,  unit_price, order_value, direct_unit_price, order_Price, Paypal, Paypal_fee_usd, China_exprice_ind, Rate_of_ex_inr, Order_price_inr,  Freight, Freight_charges,  Insurance, Insurance_value,   Landing, Landing_value, Assessable_value, Basic_duty, BCD_Value, Sw_charges,  GST, GST_value,  CD_total,  Shipping_fee, Shipping_value, Fuel_charges, Fuel_value, GST_value2, Total_shipping, Total, GST_recover, Total_landing_without_GST, Direct_landing, Indirect_basic, Extra_shipping_per_kg,  stocks,  Shipping_extra, Tax_on, Total_shipping2, China_purchase, BCD,  CP_BCD, CP_BCD_TS, CP_BCD_TS, CP_BCD_TS_Unit, IRS_Profit, Income_tax, GST2, Profit_on_cp,Income_tax_cp, Selling_1_price, Selling_GST, unit_price_selling, Price_Include_GST, Profit, income_tax22, Selling_2_Price, Selling_2_GST, unit_price_selling2, unit_price_Seliing_GST, Profit2, Income_tax_2, Selling_3_Price, Selling_3_GST,  unit_price_selling3, unit_price_Seliing_GST_2, Indirect, USD_TO_RMB,  INR_Value, final_unit_price, final_order_value, RMB, RMB_to_INR FROM general_details")
        details = cur.fetchall()
        for data in details[0:5]:
            print(data, '-------------------------')
            print(details)
    if request.method == "POST":
        id = request.args.get('id')
        print(id)
        if (request.form['product']=="" and  request.form['SKU']=="" ):
            
            cur = conp.cursor()
            cur.execute("SELECT id, product,SKU, brand_name, brand_c ,brand_sc, length,width,height,volume,weight ,weight_compair, packing, order_qty, total_weight,  unit_price, order_value, direct_unit_price, order_Price, Paypal, Paypal_fee_usd, China_exprice_ind, Rate_of_ex_inr, Order_price_inr,  Freight, Freight_charges,  Insurance, Insurance_value,   Landing, Landing_value, Assessable_value, Basic_duty, BCD_Value, Sw_charges,  GST, GST_value,  CD_total,  Shipping_fee, Shipping_value, Fuel_charges, Fuel_value, GST_value2, Total_shipping, Total, GST_recover, Total_landing_without_GST, Direct_landing, Indirect_basic, Extra_shipping_per_kg,  stocks,  Shipping_extra, Tax_on, Total_shipping2, China_purchase, BCD,  CP_BCD, CP_BCD_TS, CP_BCD_TS, CP_BCD_TS_Unit, IRS_Profit, Income_tax, GST2, Profit_on_cp,Income_tax_cp, Selling_1_price, Selling_GST, unit_price_selling, Price_Include_GST, Profit, income_tax22, Selling_2_Price, Selling_2_GST, unit_price_selling2, unit_price_Seliing_GST, Profit2, Income_tax_2, Selling_3_Price, Selling_3_GST,  unit_price_selling3, unit_price_Seliing_GST_2, Indirect, USD_TO_RMB,  INR_Value, final_unit_price, final_order_value, RMB, RMB_to_INR FROM general_details")
            details = cur.fetchall()
        elif (request.form['product'] != ""):
            pass
            product = request.form['product']
            print('============================',product)
            cur = conp.cursor()
            cur.execute("SELECT id, product,SKU, brand_name, brand_c ,brand_sc, length,width,height,volume,weight ,weight_compair, packing, order_qty, total_weight,  unit_price, order_value, direct_unit_price, order_Price, Paypal, Paypal_fee_usd, China_exprice_ind, Rate_of_ex_inr, Order_price_inr,  Freight, Freight_charges,  Insurance, Insurance_value,   Landing, Landing_value, Assessable_value, Basic_duty, BCD_Value, Sw_charges,  GST, GST_value,  CD_total,  Shipping_fee, Shipping_value, Fuel_charges, Fuel_value, GST_value2, Total_shipping, Total, GST_recover, Total_landing_without_GST, Direct_landing, Indirect_basic, Extra_shipping_per_kg,  stocks,  Shipping_extra, Tax_on, Total_shipping2, China_purchase, BCD,  CP_BCD, CP_BCD_TS, CP_BCD_TS, CP_BCD_TS_Unit, IRS_Profit, Income_tax, GST2, Profit_on_cp,Income_tax_cp, Selling_1_price, Selling_GST, unit_price_selling, Price_Include_GST, Profit, income_tax22, Selling_2_Price, Selling_2_GST, unit_price_selling2, unit_price_Seliing_GST, Profit2, Income_tax_2, Selling_3_Price, Selling_3_GST,  unit_price_selling3, unit_price_Seliing_GST_2, Indirect, USD_TO_RMB,  INR_Value, final_unit_price, final_order_value, RMB, RMB_to_INR FROM general_details where product=%s",(product,))
            details = cur.fetchall()
        elif (request.form['SKU'] != ""):
            pass
            SKU = request.form['SKU']
            print('============================',SKU)
            cur = conp.cursor()
            cur.execute("SELECT id, product,SKU, brand_name, brand_c ,brand_sc, length,width,height,volume,weight ,weight_compair, packing, order_qty, total_weight,  unit_price, order_value, direct_unit_price, order_Price, Paypal, Paypal_fee_usd, China_exprice_ind, Rate_of_ex_inr, Order_price_inr,  Freight, Freight_charges,  Insurance, Insurance_value,   Landing, Landing_value, Assessable_value, Basic_duty, BCD_Value, Sw_charges,  GST, GST_value,  CD_total,  Shipping_fee, Shipping_value, Fuel_charges, Fuel_value, GST_value2, Total_shipping, Total, GST_recover, Total_landing_without_GST, Direct_landing, Indirect_basic, Extra_shipping_per_kg,  stocks,  Shipping_extra, Tax_on, Total_shipping2, China_purchase, BCD,  CP_BCD, CP_BCD_TS, CP_BCD_TS, CP_BCD_TS_Unit, IRS_Profit, Income_tax, GST2, Profit_on_cp,Income_tax_cp, Selling_1_price, Selling_GST, unit_price_selling, Price_Include_GST, Profit, income_tax22, Selling_2_Price, Selling_2_GST, unit_price_selling2, unit_price_Seliing_GST, Profit2, Income_tax_2, Selling_3_Price, Selling_3_GST,  unit_price_selling3, unit_price_Seliing_GST_2, Indirect, USD_TO_RMB,  INR_Value, final_unit_price, final_order_value, RMB, RMB_to_INR FROM general_details where SKU=%s",(SKU,))
            details = cur.fetchall()
        else:
            pass
            SKU = request.form['SKU']
            product = request.form['product']
            cur = conp.cursor()
            cur.execute("SELECT id, product,SKU, brand_name, brand_c ,brand_sc, length,width,height,volume,weight ,weight_compair, packing, order_qty, total_weight,  unit_price, order_value, direct_unit_price, order_Price, Paypal, Paypal_fee_usd, China_exprice_ind, Rate_of_ex_inr, Order_price_inr,  Freight, Freight_charges,  Insurance, Insurance_value,   Landing, Landing_value, Assessable_value, Basic_duty, BCD_Value, Sw_charges,  GST, GST_value,  CD_total,  Shipping_fee, Shipping_value, Fuel_charges, Fuel_value, GST_value2, Total_shipping, Total, GST_recover, Total_landing_without_GST, Direct_landing, Indirect_basic, Extra_shipping_per_kg,  stocks,  Shipping_extra, Tax_on, Total_shipping2, China_purchase, BCD,  CP_BCD, CP_BCD_TS, CP_BCD_TS, CP_BCD_TS_Unit, IRS_Profit, Income_tax, GST2, Profit_on_cp,Income_tax_cp, Selling_1_price, Selling_GST, unit_price_selling, Price_Include_GST, Profit, income_tax22, Selling_2_Price, Selling_2_GST, unit_price_selling2, unit_price_Seliing_GST, Profit2, Income_tax_2, Selling_3_Price, Selling_3_GST,  unit_price_selling3, unit_price_Seliing_GST_2, Indirect, USD_TO_RMB,  INR_Value, final_unit_price, final_order_value, RMB, RMB_to_INR FROM general_details where SKU=%s, product=%s", (SKU, product,))
            details = cur.fetchall()    
            
    return render_template('Db.html', detail = details)

from flask import Response

@app.route('/Delete/<string:id_data>')
def delete(id_data):
        flash("Record Has Been Deleted Successfully")
        cur = conp.cursor()
        cur.execute("DELETE FROM general_details WHERE id=%s", (id_data,))
        conp.commit()
        return redirect(url_for('M2'))



@app.route('/update',methods=['POST','GET'])
def update():
    
 if request.method == 'POST':
     id_data = request.form['id']
     product = request.form['product']
     
     stock_loctn = request.form['stock_loctn']
     stocks = request.form['stocks']
     flash("Data Updated Successfully")
     cur = conp.cursor()
     cur.execute("UPDATE general_details SET product=%s,  stocks=%s ,stock_loctn=%s WHERE id=%s", (product, stocks,stock_loctn , id_data))
     conp.commit()
     return redirect(url_for('M2'))


        
    
   
@app.route('/getData/', methods=['GET', 'POST'])
def m1():
    print('hi we are here--------')
    if request.method == "GET":
        id = request.args.get('id')
        print(id)
        detail = []
        cur = conp.cursor()
        cur.execute("SELECT id, product, SKU,brand_name, brand_c ,brand_sc, volume, weight_compair ,Price_Include_GST, unit_price_Seliing_GST, unit_price_Seliing_GST_2,stocks,stock_loctn FROM general_details")
        details = cur.fetchall()
        for data in details[0:5]:
            print(data, '-------------------------')
            print(detail)

    if request.method == "POST":
        id = request.args.get('id')
        print(id)
        if (request.form['product']=="" and request.form['SKU']=="" and request.form['brand_name']=="" and request.form['brand_c']==""):
            detail = []
            cur = conp.cursor()
            cur.execute("SELECT id,  product, SKU,brand_name, brand_c,brand_sc ,volume, weight_compair  ,Price_Include_GST, unit_price_Seliing_GST, unit_price_Seliing_GST_2,stocks ,stock_loctn   FROM general_details")
            details = cur.fetchall()
        elif (request.form['product'] != ""):
            pass
            product = request.form['product']
            print('============================',product)
            cur = conp.cursor()
            cur.execute("SELECT id, product, SKU,brand_name, brand_c ,  brand_sc,  stocks ,stock_loctn FROM general_details where product=%s",(product,))
            details = cur.fetchall()
        elif (request.form['SKU'] != ""):
            pass
            SKU = request.form['SKU']
            print('============================',SKU)
            cur = conp.cursor()
            cur.execute("SELECT id, product, SKU,brand_name, brand_c ,brand_sc , volume, weight_compair ,Price_Include_GST, unit_price_Seliing_GST, unit_price_Seliing_GST_2,stocks  ,stock_loctn FROM general_details where SKU=%s",(SKU,))
            details = cur.fetchall()
        elif (request.form['brand_name'] !=""):
            pass
            brand_name = request.form['brand_name']
            print('============================',brand_name)
            cur = conp.cursor()
            cur.execute("SELECT id, product, SKU,brand_name, brand_c ,brand_sc , volume, weight_compair ,Price_Include_GST, unit_price_Seliing_GST, unit_price_Seliing_GST_2,stocks ,stock_loctn  FROM general_details where brand_name=%s",(brand_name,))
            details = cur.fetchall()
        elif (request.form['brand_c'] !=""):
            pass
            brand_c = request.form['brand_c']
            print('============================',brand_c)
            cur = conp.cursor()
            cur.execute("SELECT id, product, SKU,brand_name, brand_c ,brand_sc , volume, weight_compair ,Price_Include_GST, unit_price_Seliing_GST, unit_price_Seliing_GST_2,stocks ,stock_loctn  FROM general_details where brand_c=%s",(brand_c,))
            details = cur.fetchall()
        else:
            pass
            SKU = request.form['SKU']
            brand_name = request.form['brand_name']
            brand_c = request.form['brand_c']
            cur = conp.cursor()
            cur.execute("SELECT id, product, SKU,brand_name, brand_c ,brand_sc , volume, weight_compair ,Price_Include_GST, unit_price_Seliing_GST, unit_price_Seliing_GST_2,stocks  ,stock_loctn  FROM general_details where SKU=%s, product=%s, brand_name=%s, brand_c=%s",(SKU,product, brand_name, brand_c,))
            details = cur.fetchall()
        
        
    return render_template('getData.html', detail = details)











if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)



